// Navegação suave e funcionalidades da landing page

document.addEventListener('DOMContentLoaded', function() {
    
    // ========== NAVEGAÇÃO SUAVE ==========
    const navLinks = document.querySelectorAll('.nav-link');
    const header = document.getElementById('header');
    
    // Adicionar evento de clique suave para todos os links de navegação
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                const headerHeight = header.offsetHeight;
                const targetPosition = targetSection.offsetTop - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
                
                // Fechar menu mobile se estiver aberto
                const nav = document.getElementById('nav');
                nav.classList.remove('active');
            }
        });
    });
    
    // ========== HEADER SCROLL EFFECT ==========
    let lastScroll = 0;
    window.addEventListener('scroll', function() {
        const currentScroll = window.pageYOffset;
        
        if (currentScroll > 100) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
        
        // Atualizar link ativo baseado na seção visível
        updateActiveNavLink();
        
        lastScroll = currentScroll;
    });
    
    // ========== ATUALIZAR LINK ATIVO NA NAVEGAÇÃO ==========
    function updateActiveNavLink() {
        const sections = document.querySelectorAll('.section, .hero');
        const scrollPosition = window.pageYOffset + header.offsetHeight + 100;
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');
            
            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                navLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === `#${sectionId}`) {
                        link.classList.add('active');
                    }
                });
            }
        });
    }
    
    // ========== MENU MOBILE TOGGLE ==========
    const menuToggle = document.getElementById('menuToggle');
    const nav = document.getElementById('nav');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            nav.classList.toggle('active');
            
            // Animar o botão hamburger
            const spans = menuToggle.querySelectorAll('span');
            if (nav.classList.contains('active')) {
                spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
                spans[1].style.opacity = '0';
                spans[2].style.transform = 'rotate(-45deg) translate(7px, -6px)';
            } else {
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            }
        });
    }
    
    // Fechar menu ao clicar fora
    document.addEventListener('click', function(e) {
        if (!nav.contains(e.target) && !menuToggle.contains(e.target)) {
            nav.classList.remove('active');
            const spans = menuToggle.querySelectorAll('span');
            spans[0].style.transform = 'none';
            spans[1].style.opacity = '1';
            spans[2].style.transform = 'none';
        }
    });
    
    // ========== FORMULÁRIO RSVP ==========
    const rsvpForm = document.getElementById('rsvpForm');
    const rsvpMessage = document.getElementById('rsvpMessage');
    
    if (rsvpForm) {
        rsvpForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Obter valores do formulário
            const formData = {
                nome: document.getElementById('nome').value.trim(),
                email: document.getElementById('email').value.trim(),
                telefone: document.getElementById('telefone').value.trim(),
                presenca: document.getElementById('presenca').value,
                acompanhantes: document.getElementById('acompanhantes').value,
                mensagem: document.getElementById('mensagem').value.trim()
            };
            
            // Validação básica
            if (!formData.nome || !formData.email || !formData.presenca) {
                showMessage('Por favor, preencha todos os campos obrigatórios!', 'error');
                return;
            }
            
            // Validação de email
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(formData.email)) {
                showMessage('Por favor, insira um e-mail válido!', 'error');
                return;
            }
            
            // Simular envio (aqui você pode integrar com um backend ou serviço de email)
            showMessage('Obrigado pela confirmação! Sua presença é muito importante para nós. ❤️', 'success');
            
            // Salvar no localStorage (opcional - para manter os dados localmente)
            saveRSVPToLocalStorage(formData);
            
            // Limpar formulário após 3 segundos
            setTimeout(() => {
                rsvpForm.reset();
                hideMessage();
            }, 5000);
        });
    }
    
    function showMessage(message, type) {
        rsvpMessage.textContent = message;
        rsvpMessage.className = `rsvp-message ${type}`;
        rsvpMessage.style.display = 'block';
        
        // Scroll suave até a mensagem
        rsvpMessage.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    
    function hideMessage() {
        rsvpMessage.style.display = 'none';
        rsvpMessage.className = 'rsvp-message';
    }
    
    function saveRSVPToLocalStorage(data) {
        try {
            let rsvpData = JSON.parse(localStorage.getItem('rsvpData')) || [];
            data.timestamp = new Date().toISOString();
            rsvpData.push(data);
            localStorage.setItem('rsvpData', JSON.stringify(rsvpData));
        } catch (e) {
            console.log('Não foi possível salvar no localStorage:', e);
        }
    }
    
    // ========== FUNCIONALIDADE DE PRESENTES ==========
    const presenteButtons = document.querySelectorAll('.btn-presente');
    
    presenteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const presenteNome = this.getAttribute('data-presente');
            const presenteCard = this.closest('.presente-card');
            
            // Verificar se já foi escolhido
            if (this.disabled) {
                if (presenteNome === 'Pix') {
                    showPixInfo();
                }
                return;
            }
            
            // Confirmar escolha
            const confirmar = confirm(`Você deseja escolher o presente: ${presenteNome}?`);
            
            if (confirmar) {
                // Desabilitar botão
                this.disabled = true;
                this.textContent = 'Escolhido!';
                this.style.backgroundColor = '#28a745';
                
                // Adicionar mensagem de confirmação
                const confirmacao = document.createElement('div');
                confirmacao.className = 'confirmacao';
                confirmacao.innerHTML = `
                    <p><strong>Obrigado!</strong></p>
                    <p>Você escolheu: <strong>${presenteNome}</strong></p>
                    <p>Agradecemos muito pelo carinho! ❤️</p>
                `;
                presenteCard.appendChild(confirmacao);
                
                // Salvar escolha no localStorage
                savePresenteToLocalStorage(presenteNome);
                
                // Se for PIX, mostrar informações
                if (presenteNome === 'Pix') {
                    setTimeout(() => {
                        showPixInfo();
                    }, 1000);
                }
            }
        });
    });
    
    function showPixInfo() {
        const pixInfo = `
            Chave PIX: casamento@lorenaewillian.com.br\n
            Ou escaneie o QR Code abaixo (adicione uma imagem do QR Code)\n\n
            Obrigado pela contribuição! ❤️
        `;
        alert(pixInfo);
    }
    
    function savePresenteToLocalStorage(presenteNome) {
        try {
            let presentesEscolhidos = JSON.parse(localStorage.getItem('presentesEscolhidos')) || [];
            if (!presentesEscolhidos.includes(presenteNome)) {
                presentesEscolhidos.push(presenteNome);
                localStorage.setItem('presentesEscolhidos', JSON.stringify(presentesEscolhidos));
            }
        } catch (e) {
            console.log('Não foi possível salvar no localStorage:', e);
        }
    }
    
    // ========== ANIMAÇÃO DE ELEMENTOS AO SCROLL ==========
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observar elementos para animação
    const animateElements = document.querySelectorAll('.detalhe-card, .padrinho-card, .presente-card, .galeria-item');
    animateElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
    
    // ========== INICIALIZAÇÃO ==========
    // Definir link ativo inicial
    if (window.pageYOffset < 100) {
        const inicioLink = document.querySelector('a[href="#inicio"]');
        if (inicioLink) {
            inicioLink.classList.add('active');
        }
    }
    
    // Prevenir comportamento padrão de links vazios
    document.querySelectorAll('a[href="#"]').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
        });
    });
    
    console.log('🎉 Site de casamento carregado com sucesso!');
});
